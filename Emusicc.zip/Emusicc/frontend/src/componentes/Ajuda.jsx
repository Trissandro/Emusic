import React, {useState } from 'react';
import Cabecalho from './Cabecalho';
import Rodape from './Rodape';
import axios from 'axios';
import './ajuda.css';



const Ajuda = () => {
  const currentuserId = localStorage.getItem('currentuserId');
  console.log('user id do login: ',currentuserId); // Exemplo de uso do ID do usuário
  
  if (!localStorage.getItem('currentuserId')) {
    localStorage.removeItem('currentuserId');
    alert('Logout já foi feito e será reencaminhado ao ecrã de Login');
    window.location.href = `/`;
  }

  const [caixajuda,setCaixajuda]= useState({
    caixaajuda:""
  });

  const handleChange = (e) =>{
    setCaixajuda(prev=>({...prev, [e.target.name]: e.target.value}));
  };

  const handleClick = async (event) => {
    event.preventDefault();

    const formData = new FormData();
    formData.append('caixaajuda', caixajuda.caixaajuda);

    try {
      await axios.post('http://localhost:8800/ajuda', formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      });

      console.log('Ajuda enviada com sucesso');
    } catch (error) {
      console.error('Erro ao enviar a ajuda:', error);
    }
  };

  return (
    <>
    <Cabecalho></Cabecalho>
    <div className='textajuda'>Em que poderemos ajudá-lo?</div>
    <div className='Caixa'>
    <input className='Caixa-ajuda' type='text' onChange={handleChange} name='caixaajuda'>

    </input>
    <button type='submit' onClick={handleClick}>Enviar</button>
    </div>

    <Rodape></Rodape>
    </>
    
  )
}

export default Ajuda;