import React, { useEffect, useState } from 'react'
import Cabecalho from './Cabecalho';
import Rodape from './Rodape';
import './perfil.css';
import axios from 'axios';
import { Link } from 'react-router-dom';


const Perfiloutrapessoa = () => {
  const [videos,setVideos]=useState([]);

  const currentuserId = localStorage.getItem('currentuserId');
  console.log('user id do login: ',currentuserId); // Exemplo de uso do ID do usuário
  const autormusicaid = sessionStorage.getItem('autormusicaid');
console.log(autormusicaid); // Exemplo de uso do ID do usuário
  
  const [users, setUsers] = useState([]);
  const [nameuser, setNameUser] = useState([]);
  const [emailuser, setEmailUser] = useState([]);
  const [seguindouser, setSeguindoUser] = useState([]);
  const [seguidoresuser, setSeguidoresUser] = useState([]);
  const [adminuser, setAdminUser]=useState('false');





  const obterVideos = async (autormusicaid, admin) => {
    try {
      const response = await axios.get(`http://localhost:3333/midia/${autormusicaid}?admin=${admin}`);
      setVideos(response.data);
    } catch (error) {
      console.error('Erro ao obter vídeos:', error);
    }
  };
  useEffect(() => {
    obterVideos(autormusicaid, adminuser);
  }, [autormusicaid,adminuser]);

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await axios.get(`http://localhost:3333/dadouser/${autormusicaid}`);
        setUsers(response.data);
        setNameUser(response.data.name)
        setEmailUser(response.data.email)
        setSeguidoresUser(response.data.seguidores)
        setSeguindoUser(response.data.seguindo)
        setAdminUser('false')

      } catch (error) {
        console.error('Erro ao buscar usuários:', error);
      }
    };

    fetchUsers();
  }, [autormusicaid]);
  console.log('users: ', users)
  return (
    <>
      <Cabecalho></Cabecalho>
      <div className="container">
          <div className="bottom-content2">
            <h2>Midias do Cantor</h2>
            {videos.length === 0 ? (
              <p>Não carregou nenhuma mídia</p>
            ) : (
              videos.map((video) => (
                <div className="videosperfil" key={video.id}>
                  {video.tipo === "video" ? (
                    <div>
                      <img src={video.capa} alt={video.titulo} />
                      <Link to={`/videoplayer/${video.id}`}>
                        <video>
                          <source src={video.path} type="video/mp4" />
                        </video>
                      </Link>
                    </div>
                  ) : (
                    <div>
                      <img src={video.capa} alt={video.titulo} />
                      <Link to={`/Reproduziraudio/${video.id}`}>
                        <audio controls pause>
                          <source src={video.path} type="audio/mp3" />
                        </audio>
                      </Link>
                    </div>
                  )}
  
                  <h3>{video.titulo}</h3>
                  <p>{video.historia}</p>
                </div>
              ))
            )}
          </div>
  
        <div className="divider-gray"></div>
  
        <div className="right-content">
          <div className="cont">
            <div className="Atualizar dados">
                <h2>Dados do Cantor</h2>
              <p>Nome: {nameuser}</p>
              <p>Email: {emailuser}</p>
            </div>
          </div>
  
          <div className="divider-gray1"></div>
          <div className="bottom-content">
            <div className="Atualizar dados">
              <h2>Amigos & Seguidores</h2>
              <p>Seguidores: {seguidoresuser}</p>
              <p>Seguindo: {seguindouser}</p>
            </div>
          </div>
        </div>
      </div>
      <Rodape></Rodape>
    </>
  );
                  }

export default Perfiloutrapessoa;