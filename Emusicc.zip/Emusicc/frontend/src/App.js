import React from "react";
import { Route, BrowserRouter, Routes } from "react-router-dom";
import Cadastrar from "./componentes/Cadastrar.jsx";
import Perfil from "./componentes/Perfil";
import Home from "./componentes/Home.jsx";
import Actualizarusuario from "./componentes/Actualizarusuario.jsx";
import Actualizarvideo from "./componentes/Actualizarvideo.jsx";
import Termos from "./componentes/Termos.jsx";
import Reproduzirvideo from "./componentes/Reproduzirvideo.jsx";
import Reproduziraudio from "./componentes/Reproduziraudio.jsx";
import Ajuda from "./componentes/Ajuda.jsx";
import Actualizaraudio from "./componentes/Actualizaraudio.jsx";
import Sobre from './componentes/Sobre.jsx'
import Contactos from "./componentes/Contactos.jsx";
import Aplicacaomobile from "./componentes/Aplicacaomobile.jsx";
import Login from "./componentes/Login.jsx";
import Servicos from "./componentes/Servicos.jsx";
import Rodape from "./componentes/Rodape.jsx";
import VideoPlayer from "./componentes/videoplayer.jsx";
import Radio from "./componentes/Radio.jsx";
import Perfiloutrapessoa from "./componentes/Perfiloutrapessoa.jsx";
import Video from "./componentes/Video.jsx";
import Musica from "./componentes/Musica.jsx";
import './App.css';


function App() {

  return (
    <div className="App">
       <BrowserRouter>
          <Routes>
                <Route  path="/" element={<Login/>} />
                <Route  path="/Perfil" element={<Perfil/>} />
                <Route  path="/Cadastrar" element={<Cadastrar/>} />
                <Route  path="/Termos" element={<Termos/>} />
                <Route  path="/Ajuda" element={<Ajuda/>} />
                <Route  path="/Contactos" element={<Contactos/>} />
                <Route  path="/Sobre" element={<Sobre/>} />
                <Route  path="/Aplicacaomobile" element={<Aplicacaomobile/>} />
                <Route  path="/Home" element={<Home/>} />
                <Route  path="/Musica" element={<Musica/>} />
                <Route  path="/Video" element={<Video/>} />
                <Route  path="/Servicos" element={<Servicos/>} />
                <Route  path="/Rodape" element={<Rodape/>} />
                <Route  path="/Radio" element={<Radio/>} />
                <Route  path="/Cantor" element={<Perfiloutrapessoa/>} />
                <Route  path="/Reproduzirvideo" element={<Reproduzirvideo/>} />
                <Route  path="/Videoplayer/:idvideo" element={<VideoPlayer/>} />
                <Route  path="/Reproduziraudio/:idaudio" element={<Reproduziraudio/>} />
                <Route path="/Actualizarvideo/:idvideo" element={<Actualizarvideo/>}/>
                <Route  path="/Actualizaraudio/:idaudio" element={<Actualizaraudio/>} />
                <Route  path="/Actualizarusuario" element={<Actualizarusuario/>} />




           </Routes>
       </BrowserRouter>
    </div>
  );
}

export default App;

/*
import Home from "./Home";
import Sobre from "./Sobre";
import Usuario from "./Usuario";

const Routes = () => {
   return(
       <BrowserRouter>
           <Route component = { Home }  path="/" exact />
           <Route component = { Sobre }  path="/sobre" />
           <Route component = { Usuario }  path="/usuario" />
       </BrowserRouter>
   )
}
*/