import "expo-router/entry";
import * as firebase from 'firebase/app'