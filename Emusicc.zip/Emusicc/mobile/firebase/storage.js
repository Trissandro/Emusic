import { getStorage ,getDownloadURL, ref, uploadBytesResumable } from 'firebase/storage';
import app from './config';

  export const uploadFile=(name, file)=>   new Promise((resolve, rejected) => { 
    const bucket = getStorage(app)
    const storageRef = ref(bucket, `entities/${name}`);


    const uploadFiles = uploadBytesResumable(storageRef, file);

    uploadFiles.on(
      'state_changed',
      () => {
        // loading
      },
      (error) => rejected(error),
      () => resolve(getDownloadURL(uploadFiles.snapshot.ref).then((url) => url))
    )
  });