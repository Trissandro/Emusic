// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyC38YQ-fhK_H-OIVF-O42GtItqwEBFsgBY",
  authDomain: "multimediaprojecto.firebaseapp.com",
  projectId: "multimediaprojecto",
  storageBucket: "multimediaprojecto.appspot.com",
  messagingSenderId: "829240785002",
  appId: "1:829240785002:web:4a2e83dbb39571f34c7213",
  measurementId: "G-HFW9JXME9V"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export default app;